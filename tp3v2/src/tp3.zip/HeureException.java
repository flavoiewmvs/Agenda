/*
 * exception sur un heure invalide
 */

/**
 *
 * @author flavoie
 */
    public class HeureException extends Exception{
    
    public HeureException(String message){
        super(message);
    }
}
